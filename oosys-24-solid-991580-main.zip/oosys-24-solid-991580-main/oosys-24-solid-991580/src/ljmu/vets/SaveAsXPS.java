package ljmu.vets;

public class SaveAsXPS implements SaveAsFile {

	@Override
	public void saveFile(Saveable s, String path) {
		// Specifically for saving as XPS
		
	}

}
