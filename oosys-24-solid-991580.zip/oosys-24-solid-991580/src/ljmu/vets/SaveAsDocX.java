package ljmu.vets;

public class SaveAsDocX implements SaveAsFile {

	@Override
	public void saveFile(Saveable s, String path) {
		// Specifically for saving as DocX
		
	}

}
