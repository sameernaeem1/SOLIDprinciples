package ljmu.vets;

public enum FileType {
	DOCX, XPS, PDF;
}
