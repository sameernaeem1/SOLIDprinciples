package ljmu.vets;

public enum Breeding {
	MOGGIE, PEDIGREE;
}
