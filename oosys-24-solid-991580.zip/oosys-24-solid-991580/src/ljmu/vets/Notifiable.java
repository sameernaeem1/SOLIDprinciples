package ljmu.vets;

public interface Notifiable {
	public void notifyy(String s);
}
